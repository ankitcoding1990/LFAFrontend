import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Title } from "@angular/platform-browser";
import { DataService } from '../services/data.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
@Component({
	selector: 'app-cir',
	templateUrl: './cir.component.html',
	styleUrls: ['./cir.component.css']
})
export class CirComponent implements OnInit {
	serverErrors = [];
	loggeduser_id:any;
	clientInfo:any;
	ClientInfoForm: any;
	MarrigeSeprtionForm: any;
	OpposingPartyInfoForm: any;
	ChildrenForm: any;
	ChildrenLivingSituationForm: any;
	CustodyVisitationForm: any;
	declarationForm: any;
	FinancialInfoForm: any;
	MonthlyIncomeForm: any;
	MonthlyDeductionForm: any;
	AssetsForm: any;
	DebtsForm: any;
	MarrigeSeprationInfo:any;
	OppsingPartyinfo:any;
	ChildrenDetails:any;
	singleChild:any;
	ChildrenLivingDetails:any;
	singleChildLiving:any;
	ChildLivingform_submitted:boolean = false;
	ClientInfo_submitted: boolean = false;
	MarrigeSeprtionForm_submitted:boolean = false;
	marriage_separation_info: boolean = false;
	children_form: boolean = false;
	children_add_button: boolean = true;
	save_next_children_form: boolean = true;
	child_living_add_button: boolean = true;
	children_living_form: boolean = false;
	save_next_children_living_form: boolean = true;
	asset_debts_save_next: boolean = true;
	debts_form: boolean = false;
	asset_form: boolean = false;
	debts_add_button: boolean = true;
	asset_add_button: boolean = true;
	employemnt_info: boolean = false;
	DeclarationForm_submitted:boolean = false;
	OpposingPartyInfo_submitted:boolean =false;
	ChildrenInfo_submitted:boolean =false;
	FinancialInfoForm_submitted:boolean = false;
	genderlist: any = [];
	statelist: any;
	financial_info_details:any;
	declarationdetails:any;
	total_income:any;
	Monthly_income:any;
	Monthly_deductions:any;
	clinet_situation:any;
	ClientLivingSituationForm:any;
	HealthInsuranceForm:any;
	heath_insurance:any;
	get_assets_details:any;
	get_debts_details:any;
	AssetsForm_submittd:boolean=false;
	DebtsForm_submitted:boolean=false;
	HealthInsuranceForm_submitted:boolean=false;
	ClientLivingSituation_submitted:boolean=false;
	MonthlyDeductionForm_submitted:boolean =false;
	client_living_add_button:boolean=true;
	holidays_special_occasions:boolean=false;
	holiday_add_button:boolean=true;
	client_living_form:boolean=false;
	MonthlyIncomeForm_submitted:boolean=false;
	day_of_week: any[] = [
		{ value: "monday", name: "Monday" },
		{ value: "tuesday", name: "Tuesday" },
		{ value: "wednesday", name: "Wednesday" },
		{ value: "thursday", name: "Thursday" },
		{ value: "friday", name: "Friday" },
		{ value: "saturday", name: "Saturday" },
		{ value: "sunday", name: "Sunday" }];
	showOtherText:  boolean =false
	showWeekendFields:  boolean =false

	checkDobProfileInitial(control: FormControl) {
		let dob_value = control.value;
		var DobProfileInitialError = {
			dobProfileError: {
				enteredName: dob_value
			}
		}
		if (dob_value == null || dob_value == "" || dob_value == undefined) {
			return null;
		}
		var date_regex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/;
		if (!(date_regex.test(dob_value))) {
			return DobProfileInitialError;
		}
		else if ((dob_value.length == 10) && (dob_value.substring(6, 10) < 1901 || dob_value.substring(6, 10) > new Date().getFullYear())) {
			return DobProfileInitialError;
		}
		else {
			return null;
		}

	}
	constructor(
		private formBuilder: FormBuilder,
		private http: HttpClient,
		private dataService: DataService,
		private router: Router,
		private titleService: Title,

	) {
		this.titleService.setTitle("lawforall | CIR profile");

	}
	ngOnInit(): void {
		if (localStorage.getItem("email") != null) {
			this.loggeduser_id = localStorage.getItem("user_id");

		} else {
			this.router.navigate(['/sign-in'])
		}
		this.ClientInfoForm = this.formBuilder.group({
			cell_number: ['', Validators.pattern("^((\\+1-?)|0)?[0-9]{10}$")],
			user_id: [this.loggeduser_id, Validators.required],
			home_phone: ['', Validators.pattern("^((\\+1-?)|0)?[0-9]{10}$")],
			country: [''],
			city: [''],
			state: [''],
			zip_code: ['', Validators.pattern("^((\\+1-?)|0)?[0-9]{5}$")],
			address: [''],
			name: ['', Validators.required],
			maiden_name: [''],
			email: [''],
			dob: ['', this.checkDobProfileInitial],
			social_security_no: [''],
			born_place: [''],
			licence_no: [''],
			licence_state: [''],
			home_address: [''],
			living_time: [''],
			fax_number: [''],
		});
		this.FinancialInfoForm = this.formBuilder.group({
			employer_phone: ['', [Validators.required, Validators.pattern("^((\\+1-?)|0)?[0-9]{10}$")]],
			user_id: [this.loggeduser_id, Validators.required],
			home_phone: ['', Validators.pattern("^((\\+1-?)|0)?[0-9]{10}$")],
			week_hour: [''],
			pay_period: [''],
			hourly_rate: [''],
			high_school: [''],
			employer_address: [''],
			employer_name: ['', Validators.required],
			occupation: [''],
			college_complete_year: [''],
			date_job_began: ['', this.checkDobProfileInitial],
			date_job_end: ['', this.checkDobProfileInitial],
			graduate_complete_year: [''],
			degree: [''],
			licence: [''],
			last_tax_year: [''],
			filling_status: [''],
			tax_state: [''],
			deductions: ['']
		});
		this.MarrigeSeprtionForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			marriage_place: ['',Validators.required],
			marriage_date:  [''],
			separated_from_spouse_status:[''],
			date_of_separation: [''],
			proceeding_state_country: [''],
		});
		this.ChildrenForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			sex: ['',Validators.required],
			name: ['',Validators.required],
			dob: [''],
			social_security_no: [''],
			age: [''],
			city_state_birth: [''],
			id:['']
		});
		this.HealthInsuranceForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			health_insurance_through_employer: [''],
			name_insurance_company: ['',Validators.required],
			address: [''],
			phone: [''],
			assisted_medical_coverage: [''],
			name_of_program: [''],
			who_is_covered:[''],
			special_hardships:[''],
			id:['']
		});
		this.AssetsForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			asset_type: ['',Validators.required],
			asset_seperate_property: [''],
			asset_date_acquired: [''],
			asset_current_fair_market_value: [''],
			asset_balance_owed: [''],
			id:['']

		});
		this.DebtsForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			debt_type: ['',Validators.required],
			debt_seperate_property: [''],
			debt_total_owed: [''],
			debt_date_incurred: [''],
			id:['']

		});
		this.ClientLivingSituationForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			person_name: ['',Validators.required],
			person_age: [''],
			person_relation: [''],
			monthly_gross_income: [''],
			person_paying_household_expenses: [''],
			id:['']
		});
		this.ChildrenLivingSituationForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			date_from: ['',Validators.required],
			date_to: [''],
			child_living_address: [''],
			name_of_person: [''],
			present_address_of_person: [''],
			relationship: [''],
			id:['']
		});
		this.CustodyVisitationForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			custody_order_status: [''],
			protective_order_status: [''],
			physical_custody: [''],
			legal_custody: [''],
			weekend_type: [''],
			day_from: [''],
			day_to: [''],
			time_from: [''],
			time_to: [''],
			weekend_other_text: [''],
			visitation_to_other_party: [''],
			children_to_spend_time_with: [''],
			transportation_to_visit: [''],
			transportation_from_visit: [''],
			meeting_location_name:[''],
			meeting_time:[''],
			holiday:[''],
			visiter:[''],
			start_time:[''],
			end_time:[''],
			timeperiod:[''],
		});
		this.declarationForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			declaration: ['', Validators.required],

		});
		this.OpposingPartyInfoForm = this.formBuilder.group({
			user_id: ['', Validators.required],
			country: [''],
			city: [''],
			state: [''],
			zip_code: ['', Validators.pattern("^((\\+1-?)|0)?[0-9]{5}$")],
			address: [''],
			name: ['', Validators.required],
			maiden_name: [''],
			dob: ['', this.checkDobProfileInitial],
			social_security_no: [''],
			born_place: [''],
			licence_no: [''],
			licence_state: [''],
			home_address: [''],
			home_address_type: [''],
			living_time: [''],
			home_phone: ['', Validators.pattern("^((\\+1-?)|0)?[0-9]{10}$")],
			employed_status: [''],
			employer_name: [''],
			employer_address: [''],
			estimate_income: [''],
			employment_period: [''],
			income_type: ['']
		});
		this.MonthlyIncomeForm = this.formBuilder.group({

			user_id: [this.loggeduser_id, Validators.required],
			salary_wage: ['',Validators.required],
			extra_income: [''],
			self_employment: [''],
			public_ssi_disability: [''],
			alimony: [''],
			worker_compensation: [''],
			social_security: [''],
			unemployment_compensation: [''],
			dividends: [''],
			rental_income: [''],
			trust_income: [''],
			monthly_expenses: [''],
			other_monthly_income: [''],
			total_income: [''],

		});
		this.MonthlyDeductionForm = this.formBuilder.group({
			user_id: [this.loggeduser_id, Validators.required],
			federal_tax: ['',Validators.required],
			state_tax: [''],
			local_tax: [''],
			self_employment: [''],
			medicare_pay: [''],
			social_security_pay: [''],
			union_dues: [''],
			retirement_pay: [''],
			health_insurance: [''],
			court_order_paid_other: [''],
			court_order_paid_child: [''],
			court_order_paid_alimony: [''],
			court_order_paid_alimony_other: [''],
			any_other_deductions: [''],
			total_deductions: ['']

		});
		this.genderlist = [
			{ id: 1, name: 'Female' },
			{ id: 2, name: 'Male' },
			{ id: 3, name: 'Other' },
			{ id: 4, name: 'Prefer not to say' },

		];
		this.getstates();
		this.getClientInformation();
		this.getMarrigeSeprationinfo();
		this.getOpposingPartyinfo();
		this.getCirChildren();
		this.getChildLivingSituation();
		this.getDeclaration();
		this.getFinancialinfo();
		this.getMonthlyIncome();
		this.getMonthlydeduction();
		this.getClientLivingSituation();
		this.getHealthInsurance();
		this.getAssets();
		this.getDebts();
	}
	get ClientInfoFormControl() {
		return this.ClientInfoForm.controls;
	}
	get MarrigeSeprtionFormControl()
	{
		return this.MarrigeSeprtionForm.controls;
	}
	get OpposingPartyInfoFormControl()
	{
		return this.OpposingPartyInfoForm.controls;
	}
	get ChildrenFormControl()
	{
		return this.ChildrenForm.controls;
	}
	get ChildrenLivingSituationFormControl()
	{
		return this.ChildrenLivingSituationForm.controls;
	}
	get declarationFormControl()
	{
		return this.declarationForm.controls;
	}
	get FinancialInfoFormControl()
	{
		return this.FinancialInfoForm.controls;
	}
	get MonthlyIncomeFormControl()
	{
		return  this.MonthlyIncomeForm.controls;
	}
	get MonthlyDeductionFormControl()
	{
	return this.MonthlyDeductionForm.controls;
	}
	get ClientLivingSituationControl()
	{
		return this.ClientLivingSituationForm.controls;
	}
	get HealthInsuranceFormControl()
	{
		return this.HealthInsuranceForm.controls;
	}
	get AssetsFormControl()
	{
		return this.AssetsForm.controls;
	}
	get DebtsFormControl()
	{
		return this.DebtsForm.controls;
	}
	getClientInformation()
	{
		this.clientInfo = [];
		this.dataService.getCirClientInformation(this.loggeduser_id).subscribe((data: {}) => {
			this.clientInfo = data;
			this.ClientInfoForm.get("name").setValue(this.clientInfo.data.full_name);
			this.ClientInfoForm.get("maiden_name").setValue(this.clientInfo.data.maiden_name);
			this.ClientInfoForm.get("dob").setValue(this.clientInfo.data.birth_date);
			this.ClientInfoForm.get("social_security_no").setValue(this.clientInfo.data.social_security_no);
			this.ClientInfoForm.get("born_place").setValue(this.clientInfo.data.city_state_where_born);
			this.ClientInfoForm.get("licence_no").setValue(this.clientInfo.data.driver_license_number);
			this.ClientInfoForm.get("licence_state").patchValue(this.clientInfo.data.licence_state);
			this.ClientInfoForm.get("country").setValue(this.clientInfo.data.current_country);
			this.ClientInfoForm.get("state").patchValue(this.clientInfo.data.current_state);
			this.ClientInfoForm.get("city").setValue(this.clientInfo.data.current_city);
			this.ClientInfoForm.get("zip_code").setValue(this.clientInfo.data.zip_code);
			this.ClientInfoForm.get("living_time").setValue(this.clientInfo.data.how_long_lived);
			this.ClientInfoForm.get("home_phone").setValue(this.clientInfo.data.home_phone_number);
			this.ClientInfoForm.get("fax_number").setValue(this.clientInfo.data.fax_number);
			this.ClientInfoForm.get("cell_number").setValue(this.clientInfo.data.cell_phone_number);
			this.ClientInfoForm.get("email").setValue(this.clientInfo.data.email_address);
			this.ClientInfoForm.get("home_address").setValue(this.clientInfo.data.home_address);
		})
	}
	getMarrigeSeprationinfo()
	{
		this.MarrigeSeprationInfo = [];
		this.dataService.getCirMarriageSeparation(this.loggeduser_id).subscribe((data: {}) => {
			this.MarrigeSeprationInfo = data;
			this.MarrigeSeprtionForm.get("marriage_place").setValue(this.MarrigeSeprationInfo.data.marriage_place);
			this.MarrigeSeprtionForm.get("marriage_date").setValue(this.MarrigeSeprationInfo.data.marriage_date);
			this.MarrigeSeprtionForm.get("date_of_separation").setValue(this.MarrigeSeprationInfo.data.date_of_separation);
			this.MarrigeSeprtionForm.get("proceeding_state_country").setValue(this.MarrigeSeprationInfo.data.proceeding_state_country);
			if(this.MarrigeSeprationInfo.data.separated_from_spouse_status == 1)
			{
				
			}
		})
	}
	getOpposingPartyinfo()
	{
		this.OppsingPartyinfo = [];
		this.dataService.getCirOpposingPartyInfo(this.loggeduser_id).subscribe((data: {}) => {
			this.OppsingPartyinfo = data;
			this.OpposingPartyInfoForm.get("name").setValue(this.OppsingPartyinfo.data.full_name);
			this.OpposingPartyInfoForm.get("maiden_name").setValue(this.OppsingPartyinfo.data.maiden_name);
			this.OpposingPartyInfoForm.get("dob").setValue(this.OppsingPartyinfo.data.birth_date);
			this.OpposingPartyInfoForm.get("social_security_no").setValue(this.OppsingPartyinfo.data.social_security_no);
			this.OpposingPartyInfoForm.get("born_place").setValue(this.OppsingPartyinfo.data.city_state_where_born);
			this.OpposingPartyInfoForm.get("licence_no").setValue(this.OppsingPartyinfo.data.driver_license_number);
			this.OpposingPartyInfoForm.get("licence_state").patchValue(this.OppsingPartyinfo.data.licence_state);
			this.OpposingPartyInfoForm.get("country").setValue(this.OppsingPartyinfo.data.current_country);
			this.OpposingPartyInfoForm.get("state").patchValue(this.OppsingPartyinfo.data.current_state);
			this.OpposingPartyInfoForm.get("city").setValue(this.OppsingPartyinfo.data.current_city);
			this.OpposingPartyInfoForm.get("zip_code").setValue(this.OppsingPartyinfo.data.zip_code);
			this.OpposingPartyInfoForm.get("living_time").setValue(this.OppsingPartyinfo.data.how_long_lived);
			this.OpposingPartyInfoForm.get("home_phone").setValue(this.OppsingPartyinfo.data.home_phone_number);
			this.OpposingPartyInfoForm.get("home_address").setValue(this.OppsingPartyinfo.data.home_address);
			this.OpposingPartyInfoForm.get("home_address_type").patchValue(this.OppsingPartyinfo.data.home_address_type);
			this.OpposingPartyInfoForm.get("employed_status").setValue(this.OppsingPartyinfo.data.employed_status);
			this.OpposingPartyInfoForm.get("employer_name").setValue(this.OppsingPartyinfo.data.employer_name);
			this.OpposingPartyInfoForm.get("employer_address").setValue(this.OppsingPartyinfo.data.employer_address);
			this.OpposingPartyInfoForm.get("employment_period").setValue(this.OppsingPartyinfo.data.employment_period);
			this.OpposingPartyInfoForm.get("income_type").setValue(this.OppsingPartyinfo.data.income_type);
			this.OpposingPartyInfoForm.get("estimate_income").setValue(this.OppsingPartyinfo.data.estimate_income);
		})
	}
	getCirChildren()
	{
		this.ChildrenDetails =[];
		this.dataService.getCirChildren(this.loggeduser_id).subscribe((data: {}) => {
			this.ChildrenDetails = data;
		})
	}
	getChildLivingSituation()
	{
		this.ChildrenLivingDetails =[];
		this.dataService.getChildrenLivingSituation(this.loggeduser_id).subscribe((data: {}) => {
			this.ChildrenLivingDetails = data;
		})
	}
	getDeclaration()
	{
		this.declarationdetails =[];
		this.dataService.getCirDeclaration(this.loggeduser_id).subscribe((data: {}) => {
			this.declarationdetails = data;
			this.declarationForm.get("declaration").setValue(this.declarationdetails.data.declaration);
		
		})
	}
	getFinancialinfo()
	{
		this.financial_info_details =[];
		this.dataService.getCirFinancialInformation(this.loggeduser_id).subscribe((data: {}) => {
			this.financial_info_details = data;
			this.FinancialInfoForm.get("employer_name").setValue(this.financial_info_details.data.employer_name);
			this.FinancialInfoForm.get("employer_address").setValue(this.financial_info_details.data.employer_address);
			this.FinancialInfoForm.get("employer_phone").setValue(this.financial_info_details.data.employer_phone);
			this.FinancialInfoForm.get("occupation").setValue(this.financial_info_details.data.occupation);
			this.FinancialInfoForm.get("date_job_began").setValue(this.financial_info_details.data.date_job_began);
			this.FinancialInfoForm.get("date_job_end").setValue(this.financial_info_details.data.date_job_end);
			this.FinancialInfoForm.get("week_hour").setValue(this.financial_info_details.data.week_hour);
			this.FinancialInfoForm.get("pay_period").patchValue(this.financial_info_details.data.pay_period);
			this.FinancialInfoForm.get("hourly_rate").setValue(this.financial_info_details.data.hourly_rate);
			this.FinancialInfoForm.get("high_school").setValue(this.financial_info_details.data.high_school);
			this.FinancialInfoForm.get("college_complete_year").setValue(this.financial_info_details.data.college_complete_year);
			this.FinancialInfoForm.get("graduate_complete_year").setValue(this.financial_info_details.data.graduate_complete_year);
			this.FinancialInfoForm.get("degree").setValue(this.financial_info_details.data.degree);
			this.FinancialInfoForm.get("licence").setValue(this.financial_info_details.data.licence);
			this.FinancialInfoForm.get("last_tax_year").setValue(this.financial_info_details.data.last_tax_year);
			this.FinancialInfoForm.get("filling_status").patchValue(this.financial_info_details.data.filling_status);
			this.FinancialInfoForm.get("tax_state").setValue(this.financial_info_details.data.tax_state);
			this.FinancialInfoForm.get("deductions").setValue(this.financial_info_details.data.deductions);
		})
	}
	getMonthlyIncome()
	{
		this.Monthly_income =[];
		this.dataService.getCirMonthlyIncome(this.loggeduser_id).subscribe((data: {}) => {
			this.Monthly_income = data;
			this.MonthlyIncomeForm.get("salary_wage").patchValue(this.Monthly_income.data.salary_wage);
			this.MonthlyIncomeForm.get("extra_income").setValue(this.Monthly_income.data.extra_income);
			this.MonthlyIncomeForm.get("self_employment").setValue(this.Monthly_income.data.self_employment);
			this.MonthlyIncomeForm.get("public_ssi_disability").setValue(this.Monthly_income.data.public_ssi_disability);
			this.MonthlyIncomeForm.get("alimony").setValue(this.Monthly_income.data.alimony);
			this.MonthlyIncomeForm.get("worker_compensation").setValue(this.Monthly_income.data.worker_compensation);
			this.MonthlyIncomeForm.get("dividends").setValue(this.Monthly_income.data.dividends);
			this.MonthlyIncomeForm.get("unemployment_compensation").setValue(this.Monthly_income.data.unemployment_compensation);
			this.MonthlyIncomeForm.get("rental_income").patchValue(this.Monthly_income.data.rental_income);
			this.MonthlyIncomeForm.get("trust_income").setValue(this.Monthly_income.data.trust_income);
			this.MonthlyIncomeForm.get("monthly_expenses").setValue(this.Monthly_income.data.monthly_expenses);
			this.MonthlyIncomeForm.get("other_monthly_income").setValue(this.Monthly_income.data.other_monthly_income);
			this.MonthlyIncomeForm.get("total_income").setValue(this.Monthly_income.data.total_income);
	
			})
	}
	getMonthlydeduction()
	{
	this.Monthly_deductions =[];
		this.dataService.getCirMonthlyDeductions(this.loggeduser_id).subscribe((data: {}) => {
			this.Monthly_deductions = data;
			this.MonthlyDeductionForm.get("federal_tax").patchValue(this.Monthly_deductions.data.federal_tax);
			this.MonthlyDeductionForm.get("state_tax").setValue(this.Monthly_deductions.data.state_tax);
			this.MonthlyDeductionForm.get("local_tax").setValue(this.Monthly_deductions.data.local_tax);
			this.MonthlyDeductionForm.get("self_employment").setValue(this.Monthly_deductions.data.self_employment);
			this.MonthlyDeductionForm.get("medicare_pay").setValue(this.Monthly_deductions.data.medicare_pay);
			this.MonthlyDeductionForm.get("retirement_pay").setValue(this.Monthly_deductions.data.retirement_pay);
			this.MonthlyDeductionForm.get("social_security_pay").setValue(this.Monthly_deductions.data.social_security_pay);
			this.MonthlyDeductionForm.get("union_dues").setValue(this.Monthly_deductions.data.union_dues);
			this.MonthlyDeductionForm.get("health_insurance").patchValue(this.Monthly_deductions.data.health_insurance);
			this.MonthlyDeductionForm.get("court_order_paid_other").setValue(this.Monthly_deductions.data.court_order_paid_other);
			this.MonthlyDeductionForm.get("court_order_paid_child").setValue(this.Monthly_deductions.data.court_order_paid_child);
			this.MonthlyDeductionForm.get("court_order_paid_alimony").setValue(this.Monthly_deductions.data.court_order_paid_alimony);
			this.MonthlyDeductionForm.get("court_order_paid_alimony_other").setValue(this.Monthly_deductions.data.court_order_paid_alimony_other);
			this.MonthlyDeductionForm.get("any_other_deductions").setValue(this.Monthly_deductions.data.any_other_deductions)
			this.MonthlyDeductionForm.get("total_deductions").setValue(this.Monthly_deductions.data.total_deductions)
			})
	}
	getClientLivingSituation()
	{
		this.clinet_situation =[];
		this.dataService.getCirClientLivingSituation(this.loggeduser_id).subscribe((data: {}) => {
			this.clinet_situation = data;
			
		})
	}
	getHealthInsurance()
	{
		this.heath_insurance =[];
		this.dataService.getCirHealthInsurance(this.loggeduser_id).subscribe((data: {}) => {
			this.heath_insurance = data;
			this.HealthInsuranceForm.get("health_insurance_through_employer").setValue(this.heath_insurance.data.health_insurance_through_employer)
			this.HealthInsuranceForm.get("name_insurance_company").setValue(this.heath_insurance.data.name_insurance_company)
			this.HealthInsuranceForm.get("address").setValue(this.heath_insurance.data.address)
			this.HealthInsuranceForm.get("phone").setValue(this.heath_insurance.data.phone)
			this.HealthInsuranceForm.get("assisted_medical_coverage").setValue(this.heath_insurance.data.assisted_medical_coverage)
			this.HealthInsuranceForm.get("name_of_program").setValue(this.heath_insurance.data.name_of_program)
			this.HealthInsuranceForm.get("who_is_covered").setValue(this.heath_insurance.data.who_is_covered)
			this.HealthInsuranceForm.get("special_hardships").setValue(this.heath_insurance.data.special_hardships)
			
		})
	}
	getAssets()
	{
		this.get_assets_details =[];
		this.dataService.getCirAssets(this.loggeduser_id).subscribe((data: {}) => {
			this.get_assets_details = data;
					
		})
	}
	getDebts()
	{
		this.get_debts_details =[];
		this.dataService.getCirDebts(this.loggeduser_id).subscribe((data: {}) => {
			this.get_debts_details = data;
					
		})
	}
	error_popup()
	{
		
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Whoops, looks like something went wrong!',
			footer: ''
		})
	}
	client_living_situation()
	{
		this.ClientLivingSituation_submitted = true;
		if (this.ClientLivingSituationForm.valid) {
			this.dataService.submitCirClientLivingSituation(this.ClientLivingSituationForm).subscribe(
				(response) => {
					this.client_living_form=false;
					this.client_living_add_button=true;
					this.getClientLivingSituation();
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Client Living Situation updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}
	}
	show_client_living_form(e:any)
	{
	if (e.target.value == "add") {
			this.client_living_form = true;
			this.client_living_add_button = false;
		} else {
			this.client_living_form = false;
			this.client_living_add_button = true;
		}
	}
	update_client_info() {
		this.ClientInfo_submitted = true;
		if (this.ClientInfoForm.valid) {
			this.dataService.submitCirClientInformation(this.ClientInfoForm).subscribe(
				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Client information updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
			
		}
	}
	marriage_separation() {
		this.MarrigeSeprtionForm_submitted=true;
	if (this.MarrigeSeprtionForm.valid) {
		this.dataService.submitCirMarriageSeparation(this.MarrigeSeprtionForm).subscribe(
				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Client Marriage-Separation updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});

	}
	}
	opposing_party_info() {
			this.OpposingPartyInfo_submitted=true;
	if (this.OpposingPartyInfoForm.valid) {
			this.dataService.submitCirOpposingPartyInfo(this.OpposingPartyInfoForm).subscribe(
				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Oppsing party information updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
	}
	}
	children_info() {
		this.ChildrenInfo_submitted=true;
	if (this.ChildrenForm.valid) {
			this.dataService.submitCirChildren(this.ChildrenForm).subscribe(			

				(response) => {
				this.children_add_button=true;
				this.children_form=false;
				this.getCirChildren();
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Children updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
	}
	}
	children_living_info() {
		this.ChildLivingform_submitted=true;
	if (this.ChildrenLivingSituationForm.valid) {
			this.dataService.submitChildrenLivingSituation(this.ChildrenLivingSituationForm).subscribe(			

				(response) => {
				this.child_living_add_button=true;
				this.children_living_form=false;
				this.getClientLivingSituation();
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Children living situation updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
	}

	}
	custody_info() {
		//code
	}
	declaration_info() {
		this.DeclarationForm_submitted=true;
		if (this.declarationForm.valid) {
			this.dataService.submitCirDeclaration(this.declarationForm).subscribe(			

				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'declaration updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}
	}
	financial_info() {
		this.FinancialInfoForm_submitted=true;
		if (this.FinancialInfoForm.valid) {
			this.dataService.submitCirFinancialInformation(this.FinancialInfoForm).subscribe(			

				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Financial information updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}
	}
	monthlyincome_info() {
		this.MonthlyIncomeForm_submitted=true;
		if (this.MonthlyIncomeForm.valid) {
			this.dataService.submitCirMonthlyIncome(this.MonthlyIncomeForm).subscribe(			

				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Monthly Income updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}

	}
	monthly_deduction_info() {
		this.MonthlyDeductionForm_submitted=true;
		if (this.MonthlyDeductionForm.valid) {
			this.dataService.submitCirMonthlyDeductions(this.MonthlyDeductionForm).subscribe(			

				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Monthly deductions updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		
		}
	}
	health_insurance()
	{
		this.HealthInsuranceForm_submitted=true;
		if (this.HealthInsuranceForm.valid) {
			this.dataService.submitCirHealthInsurance(this.HealthInsuranceForm).subscribe(			

				(response) => {
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Health insurance updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}
	}
	assets_info() {
		this.AssetsForm_submittd=true;
		if (this.AssetsForm.valid) {
			this.dataService.submitCirAssets(this.AssetsForm).subscribe(			

				(response) => {
					this.getAssets();
					this.asset_form=false;
					this.debts_add_button=true;
					this.asset_add_button=true;
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Assets updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}
	}
	debts_info() {
		this.DebtsForm_submitted=true;
		if (this.DebtsForm.valid) {
			this.dataService.submitCirDebts(this.DebtsForm).subscribe(			

				(response) => {
					this.getDebts();
					this.debts_form=false;
					this.debts_add_button=true;
					this.asset_add_button=true;
					Swal.fire({
					icon: 'success',
					title: 'Thank you',
					text: 'Debts updated successfully!',
		})
				}, (error) => {
					this.serverErrors = error.error;
				this.error_popup();
			});
		}
	}
	total_monthly_income(e:any)
	{
		var total  =  e.target.value;

	}
	delete_client_situation(id:any)
	{
		Swal.fire({
			title: 'Are you sure?',
			text: "Delete Client Living Situation",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it'
		}).then((result) => {
			if (result.isConfirmed) {
				this.dataService.deleteCirClientLivingSituation(id).subscribe((data: {}) => {
					this.getChildLivingSituation();
					Swal.fire({
					icon: 'success',
					title: 'Deleted successfully',
		})
			})
			}
		})
		
	}
	edit_client_living_situation(id:any,name:any,relation:any,age:any,gross:any,household:any)
	{
		this.client_living_form=true;
		this.client_living_add_button=false;
		this.ClientLivingSituationForm.get("id").setValue(id);
		this.ClientLivingSituationForm.get("person_name").setValue(name);
		this.ClientLivingSituationForm.get("person_relation").patchValue(relation);
		this.ClientLivingSituationForm.get("person_age").setValue(age);
		this.ClientLivingSituationForm.get("monthly_gross_income").setValue(gross);
		this.ClientLivingSituationForm.get("person_paying_household_expenses").setValue(household);
	}
	edit_children(id:any)
	{

		this.singleChild =[];
		this.dataService.getSingleCirChild(id).subscribe((data: {}) => {
			this.singleChild = data;
			this.children_add_button=false;
			this.children_form=true;
			this.ChildrenForm.get("id").setValue(this.singleChild.data.id);
			this.ChildrenForm.get("sex").setValue(this.singleChild.data.sex);
			this.ChildrenForm.get("name").setValue(this.singleChild.data.name);
			this.ChildrenForm.get("dob").setValue(this.singleChild.data.dob);
			this.ChildrenForm.get("age").setValue(this.singleChild.data.age);
			this.ChildrenForm.get("social_security_no").setValue(this.singleChild.data.social_security_no);
			this.ChildrenForm.get("city_state_birth").setValue(this.singleChild.data.city_state_birth);

		})
	}
	edit_Child_living(id:any)
	{
		this.singleChildLiving =[];
		this.dataService.getSingleChildrenLivingSituation(id).subscribe((data: {}) => {
			this.singleChildLiving = data;
			this.child_living_add_button=false;
			this.children_living_form=true;
			this.ChildrenLivingSituationForm.get("id").setValue(this.singleChildLiving.data.id);
			this.ChildrenLivingSituationForm.get("date_from").setValue(this.singleChildLiving.data.date_from);
			this.ChildrenLivingSituationForm.get("date_to").setValue(this.singleChildLiving.data.date_to);
			this.ChildrenLivingSituationForm.get("child_living_address").setValue(this.singleChildLiving.data.child_living_address);
			this.ChildrenLivingSituationForm.get("name_of_person").setValue(this.singleChildLiving.data.name_of_person);
			this.ChildrenLivingSituationForm.get("present_address_of_person").setValue(this.singleChildLiving.data.present_address_of_person);
			this.ChildrenLivingSituationForm.get("relationship").setValue(this.singleChildLiving.data.relationship);

		})
	}
	edit_Assets(id:any,type:any,date:any,seprate:any,balance:any,value:any)
	{
		this.asset_form=true;
		this.debts_add_button=false;
		this.asset_add_button=false;
		this.AssetsForm.get("id").setValue(id);
		this.AssetsForm.get("asset_type").patchValue(type);
		this.AssetsForm.get("asset_seperate_property").setValue(seprate);
		this.AssetsForm.get("asset_date_acquired").setValue(date);
		this.AssetsForm.get("asset_balance_owed").setValue(balance);
		this.AssetsForm.get("asset_current_fair_market_value").setValue(value);
	}
	edit_Debts(id:any,type:any,seprate:any,date:any,balance:any)
	{
		this.debts_form=true;
		this.debts_add_button=false;
		this.asset_add_button=false;
		this.DebtsForm.get("id").setValue(id);
		this.DebtsForm.get("debt_type").patchValue(type);
		this.DebtsForm.get("debt_seperate_property").setValue(seprate);
		this.DebtsForm.get("debt_date_incurred").setValue(date);
		this.DebtsForm.get("debt_total_owed").setValue(balance);

	}
	delete_asset_debts(id:any)
	{
		Swal.fire({
			title: 'Are you sure?',
			text: "Delete",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it'
		}).then((result) => {
			if (result.isConfirmed) {
				this.dataService.deleteCirAssetandDebts(id).subscribe((data: {}) => {
					this.getAssets();
					this.getDebts();
					Swal.fire({
					icon: 'success',
					title: 'Deleted successfully',
		})
			})
			}
		})
	}
	show_children_form(e: any) {
		if (e.target.value == "add") {
			this.children_form = true;
			this.children_add_button = false;
			this.save_next_children_form = false;
		} else {
			this.children_form = false;
			this.children_add_button = true;
			this.save_next_children_form = true;
		}
	}
	show_child_living_form(e: any) {
		if (e.target.value == "add") {
			this.children_living_form = true;
			this.child_living_add_button = false;
			this.save_next_children_living_form = false;
		} else {
			this.children_living_form = false;
			this.child_living_add_button = true;
			this.save_next_children_living_form = true;
		}

	}
	show_asset_form(e: any) {
		if (e.target.value == "add") {
			this.asset_form = true;
			this.asset_add_button = false;
			this.asset_debts_save_next = false;
			this.debts_add_button = false;
		} else {
			this.asset_form = false;
			this.asset_add_button = true;
			this.asset_debts_save_next = true;
			this.debts_add_button = true;
		}

	}
	show_debts_form(e: any) {
		if (e.target.value == "add") {
			this.debts_form = true;
			this.asset_add_button = false;
			this.debts_add_button = false;
			this.asset_debts_save_next = false;
		} else {
			this.debts_form = false;
			this.asset_add_button = true;
			this.debts_add_button = true;
			this.asset_debts_save_next = true;
		}

	}
	//gender
	get_gender_value(event: any) {
		var gender = event.target.value;
		if (gender == "Other" || gender == "Prefer not to say" || gender == "Decline to Answer") {
			//code
		} else {
			//code
		}
	}
	getstates() {
		this.statelist = [];
		this.dataService.get_state_list().subscribe((data: {}) => {
			this.statelist = data;

		});
	}
	show_marriage_separation_info(e: any) {

		if (e.target.checked) {
			this.marriage_separation_info = true;
			this.MarrigeSeprtionForm.get("separated_from_spouse_status").setValue(1);
		} else {
			this.marriage_separation_info = false;
			this.MarrigeSeprtionForm.get("separated_from_spouse_status").setValue(0);
		}

	}
	show_emplyee_history(e: any) {
		if (e.target.value == "yes") {
			this.employemnt_info = true;
		} else {
			this.employemnt_info = false;
		}
	}
	show_add_holiday()
	{
		this.holiday_add_button=false;
		this.holidays_special_occasions=true;
	}
	checkWeekendType(event :any)
	{
		if(event.target.value=="other")
		{
			this.showOtherText=true
			this.showWeekendFields=false
		}
		else
		{
			this.showOtherText=false
			this.showWeekendFields=true
		}
		
	}

}